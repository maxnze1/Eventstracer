from django.apps import AppConfig


class DirectoryConfig(AppConfig):
    name = 'directory'
