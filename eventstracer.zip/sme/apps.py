from django.apps import AppConfig


class SmeConfig(AppConfig):
    name = 'sme'
