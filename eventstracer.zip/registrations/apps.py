from django.apps import AppConfig


class RegistraionsConfig(AppConfig):
    name = 'registrations'
